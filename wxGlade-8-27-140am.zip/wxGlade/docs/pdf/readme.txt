The makefile in wxGlade/docs generate here the pdf file.
But it is too large to put it in CVS.
Cheers.
