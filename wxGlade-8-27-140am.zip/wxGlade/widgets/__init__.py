# __init__.py: here to please SPE...
# $Id: __init__.py,v 1.1 2005/08/06 12:21:12 agriggio Exp $
#
# Copyright (c) 2002-2005 Alberto Griggio <agriggio@users.sourceforge.net>
# License: MIT (see license.txt)
# THIS PROGRAM COMES WITH NO WARRANTY
