# __init__.py: to turn wxGlade into a package
# $Id: __init__.py,v 1.3 2005/05/06 21:48:26 agriggio Exp $
#
# Copyright (c) 2002-2005 Alberto Griggio <agriggio@users.sourceforge.net>
# License: MIT (see license.txt)
# THIS PROGRAM COMES WITH NO WARRANTY
